# OAUTH2_JWT_ENABLED = True

# OAUTH2_JWT_ISS = 'https://authlib.org'
OAUTH2_JWT_KEY = "secret-key"
OAUTH2_JWT_ALG = "HS256"
