hvac.exceptions
===============

.. automodule:: hvac.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
