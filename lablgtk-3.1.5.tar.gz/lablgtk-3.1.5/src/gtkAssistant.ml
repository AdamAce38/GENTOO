open Gaux
open Gobject
open Gtk
open Tags
open GtkAssistantProps
open GtkBase

module Assistant = struct
  include Assistant
end
