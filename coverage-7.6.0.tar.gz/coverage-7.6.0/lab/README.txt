The lab directory is not part of the installed coverage.py code.  These programs
are tools I have used while diagnosing problems, investigating functionality,
and so on.  They are not guaranteed to work, or to be suitable for any given
purpose.  If you find them useful, enjoy!
